package com.example.mma;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TableRow;

public class MainMenuActivity extends AppCompatActivity {
    private Button btn_calculator;
    private Button btn_converter;
    private Button btn_equation;
    private TableRow row_calculator;
    private TableRow row_equation;
    private TableRow row_converter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);
        getSupportActionBar().setTitle("Home");
//        btn_calculator = findViewById(R.id.btn_calculator);
//        btn_converter = findViewById(R.id.btn_converter);
//        btn_equation = findViewById(R.id.btn_equation);
        row_calculator = findViewById(R.id.row_calculator);
        row_converter = findViewById(R.id.row_converter);
        row_equation = findViewById(R.id.row_equation);
//        btn_calculator.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(MainMenuActivity.this, CalculatorActivity.class);
//                startActivity(intent);
//            }
//        });
//        btn_converter.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(MainMenuActivity.this, ConverterMenuActivity.class);
//                startActivity(intent);
//            }
//        });
//        btn_equation.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(MainMenuActivity.this, EquationMenuActivity.class);
//                startActivity(intent);
//
//            }
//        });
        row_calculator.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainMenuActivity.this, CalculatorActivity.class);
                startActivity(intent);
            }
        });
        row_converter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                                Intent intent = new Intent(MainMenuActivity.this, ConverterMenuActivity.class);
                startActivity(intent);
            }
        });
        row_equation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainMenuActivity.this, EquationMenuActivity.class);
                startActivity(intent);
            }
        });
    }
}